export interface IUserModel {
    id: string;
    name: string;
    email: string;
    role: string;
    isActive: boolean;
}
