import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class NotificationsService {
    // Add notification-related methods as needed
}


