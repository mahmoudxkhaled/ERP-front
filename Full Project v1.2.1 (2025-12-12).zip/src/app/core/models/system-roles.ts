export enum Roles {
    Developer = 1,
    SystemAdministrator = 2,
    EntityAdministrator = 3,
    SystemUser = 4,
    Guest = 5,
}
