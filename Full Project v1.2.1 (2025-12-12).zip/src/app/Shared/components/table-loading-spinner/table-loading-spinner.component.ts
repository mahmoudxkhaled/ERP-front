import { Component } from '@angular/core';

@Component({
    selector: 'app-table-loading-spinner',
    templateUrl: './table-loading-spinner.component.html',
    styleUrl: './table-loading-spinner.component.scss',
})
export class TableLoadingSpinnerComponent {}


