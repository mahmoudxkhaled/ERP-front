export interface ApiResult {
  ReturnStatus: number;
  Body: string;
}
