export interface Metric {
    title: string;
    icon: string;
    fieldColor: string;
    color: string;
    files: string;
    fileSize: string;
    items: object;
}