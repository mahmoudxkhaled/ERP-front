import { Component } from '@angular/core';
import { LayoutService } from 'src/app/layout/app-services/app.layout.service';

@Component({
    templateUrl: './login2.component.html',
})
export class Login2Component {
    rememberMe: boolean = false;

    constructor(private layoutService: LayoutService) {}

    get dark(): boolean {
        return this.layoutService.config().colorScheme !== 'light';
    }
}
