import { Component } from '@angular/core';

@Component({
    templateUrl: './accessdenied2.component.html'
})
export class Accessdenied2Component { }