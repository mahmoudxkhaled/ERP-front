export interface IForceLogoutModel{
    userId : string;
    userEmail : string;
    userPassword : string;
}