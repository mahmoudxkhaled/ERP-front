export interface IResetPasswordModel{
    email: string;
    newPassword : string;
    cNewPassword : string;
}